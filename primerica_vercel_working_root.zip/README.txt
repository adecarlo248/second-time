Vercel deployment instructions

1. Upload the contents of this folder to a new Vercel project.
2. Make sure index.html is in the project root.
3. After deployment, edit the WEBHOOK_URL value near the bottom of index.html to connect your GoHighLevel webhook.
4. Redeploy.

Notes:
- This is a static HTML site, so it does not need Node, npm, or a build command.
- The logo is embedded directly into the HTML.
- Phone number is set to Tony DeCarlo: 1 (249) 504-5199.
